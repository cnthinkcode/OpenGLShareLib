//
//  main.cpp
//  openGlFirst
//
//  Created by hejianyuan on 2023/2/20.
//

#include <stdio.h>
#include "GLTools.h"
#include <glut/glut.h>

#pragma clang diagnostic push
#pragma clang diagnostic ignored"-Wdeprecated-declarations"

GLBatch triangleBatch;
GLShaderManager shaderManager;

void onChangeSize(int w,int h){
    glViewport(0,0, w, h);
}

void setupRC(){
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    shaderManager.InitializeStockShaders();
    
    GLfloat vVerts[] = {
        -0.5f, 0.5f, 0.0f,
        -0.5f, -0.5f, 0.0f,
        0.5f, -0.5f, 0.0f,
        0.5f, 0.5f, 0.0f,
    };
        
    triangleBatch.Begin(GL_TRIANGLE_FAN,4);
    triangleBatch.CopyVertexData3f(vVerts);

    triangleBatch.End();
}

void onRenderScene(void) {
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);
    
    GLfloat vColor[] = {0.0f, 0.0f, 0.0f, 1.0f};
    shaderManager.UseStockShader(GLT_SHADER_IDENTITY,vColor);
    
    triangleBatch.Draw();
    
    glutSwapBuffers();
}


int main(int argc, char *argv[]){
    
    gltSetWorkingDirectory(argv[0]);
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGBA|GLUT_DEPTH|GLUT_STENCIL);
    glutInitWindowSize(800, 600);
    glutCreateWindow("窗口");
    
    glutReshapeFunc(onChangeSize);
    glutDisplayFunc(onRenderScene);
    
    GLenum status = glewInit();
    
    if(GLEW_OK != status) {
        fprintf(stderr,"glew error:%s\n",glewGetErrorString(status));
        return 1;
    }
    
    setupRC();
    
    glutMainLoop();

    return 0;
}


#pragma clang diagnostic pop
